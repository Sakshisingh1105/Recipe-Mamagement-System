package gr.recipemanagement.service.exceptions;

/**
 * @author Ntirintis John
 */
public class NoRecipeSelectedException extends Exception{
    public NoRecipeSelectedException(String message){
        super(message);
    }

}
