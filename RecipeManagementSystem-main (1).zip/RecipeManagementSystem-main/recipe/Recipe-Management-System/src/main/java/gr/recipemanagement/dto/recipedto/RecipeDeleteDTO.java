package gr.recipemanagement.dto.recipedto;

import gr.recipemanagement.dto.BaseDTO;

/**
 * @author Ntirintis John
 */
public class RecipeDeleteDTO extends BaseDTO {

}
