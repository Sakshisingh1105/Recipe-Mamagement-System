package gr.recipemanagement.service.exceptions;

/**
 * @author Ntirintis John
 */
public class RecipeInsertException extends Exception{

    public RecipeInsertException(String message){
        super(message);
    }
}
