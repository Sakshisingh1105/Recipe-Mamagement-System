package gr.recipemanagement.dto.ingredientdto;

/**
 * @author Ntirintis John
 */
public class IngredientDeleteDTO {
}
