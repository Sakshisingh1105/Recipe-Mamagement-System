package gr.recipemanagement.service.exceptions;

/**
 * @author Ntirintis John
 */
public class IngredientNotInsertedDAOException extends Exception {

    public IngredientNotInsertedDAOException(String message){
        super(message);
    }

}
